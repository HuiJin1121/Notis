ALTER TABLE settings DROP COLUMN IF EXISTS video_ads;
ALTER TABLE settings ADD video_ads INTEGER;

ALTER TABLE settings DROP COLUMN IF EXISTS image_ads;
ALTER TABLE settings ADD image_ads INTEGER;

DELETE FROM p_subscriptions_user WHERE id = 52;