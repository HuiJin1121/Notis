@extends('layouts.backend')

@section('content')

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/highcharts-more.js"></script>
    <script src="https://code.highcharts.com/modules/solid-gauge.js"></script> 
    <script src="https://code.highcharts.com/modules/exporting.js"></script>

    <script type="text/javascript">

        function filterChange(){
            document.getElementById('select_form').submit();
        }
    
    </script>

<div class="nk-block">
    <h4 class="nk-block-title">TV Show Analysis</h4>
    <form action="{{ route('views.tvshows.all') }}" id="select_form">   
        <div class="row g-gs">
            <div class="col-3">
                <div class="form-group">
                    <label class="form-label" for="filter_p">Time Range</label>
                    <div class="form-control-wrap">
                        <select class="form-select" id="filter_p" onchange="filterChange()" name="filter_p">
                            <option value="All History" @if($filter_p == "All History") selected @endif>All History</option>
                            <option value="Yearly" @if($filter_p == "Yearly") selected @endif>Yearly</option>
                            <option value="Monthly" @if($filter_p == "Monthly") selected @endif>Monthly</option>
                            <option value="Weekly" @if($filter_p == "Weekly") selected @endif>Weekly</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <br/>
    <div class="nk-block">
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner card-inner-lg">
                        <div class="card card-preview">
                            <div class="card-inner">
                            <table class="datatable-init table">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Seasons</th>
                                            <th>Episodes</th>
                                            <th>Views</th>
                                            <th>Watch Minutes</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($tvshows as $tvshow)
                                            @php
                                                $season_count = $tvshow->seasons->count();
                                                $episode_count = 0;
                                                $time = 0;
                                                $views_count = 0;
                                                foreach($tvshow->seasons as $season){
                                                    if($season != null && $season->episodes != null){
                                                        $episode_count = $season->episodes->count();
                                                    }
                                                    foreach($season->episodes as $episode){
                                                        $time += $episode->watchtimes_sum_time ?? 0;
                                                        $views_count += $episode->views_count ?? 0;
                                                    }
                                                }
                                                $time = round($time,0);
                                                $time = convert_sec_to_min($time);
                                                $hour = floor($time / 60);
                                            @endphp
                                            <tr>
                                                <td>{{$tvshow->title}}</td>
                                                <td>{{$season_count}}</td>
                                                <td>{{$episode_count}}</td>
                                                <td>{{$views_count}}</td>
                                                <td>{{$time.' min = '.$hour.' hr'}}</td>
                                            </tr>
                                        @endforeach 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div><!-- .nk-block -->
</div><!-- .nk-block -->
@endsection